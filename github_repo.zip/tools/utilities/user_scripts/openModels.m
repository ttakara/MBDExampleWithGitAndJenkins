% Copyright 2021 The MathWorks, Inc.

% This script is used to open all the models in this project

open_system('DriverSwRequest')
open_system('CruiseControlMode')
open_system('TargetSpeedThrottle')
open_system('crs_controller')
open_system('crs_plant')
